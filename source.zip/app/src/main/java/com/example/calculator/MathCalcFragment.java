package com.example.calculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import java.util.*;

public class MathCalcFragment extends Fragment {
    private TextView tvDisplay;
    private ListView lvHistory;
    private StringBuilder currentExpression = new StringBuilder();
    private ArrayList<String> historyList = new ArrayList<>();
    private ArrayAdapter<String> historyAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_math_calc, container, false);

        tvDisplay = view.findViewById(R.id.tv_display);
        lvHistory = view.findViewById(R.id.lv_history);

        historyAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, historyList);
        lvHistory.setAdapter(historyAdapter);

        Map<Integer, String> btnValues = new HashMap<>();
        btnValues.put(R.id.btn_0, "0");
        btnValues.put(R.id.btn_1, "1");
        btnValues.put(R.id.btn_2, "2");
        btnValues.put(R.id.btn_3, "3");
        btnValues.put(R.id.btn_4, "4");
        btnValues.put(R.id.btn_5, "5");
        btnValues.put(R.id.btn_6, "6");
        btnValues.put(R.id.btn_7, "7");
        btnValues.put(R.id.btn_8, "8");
        btnValues.put(R.id.btn_9, "9");
        btnValues.put(R.id.btn_dot, ".");
        btnValues.put(R.id.btn_plus, "+");
        btnValues.put(R.id.btn_minus, "-");
        btnValues.put(R.id.btn_mul, "*");
        btnValues.put(R.id.btn_div, "/");
        btnValues.put(R.id.btn_pow, "^");
        btnValues.put(R.id.btn_perc, "%");
        btnValues.put(R.id.btn_open_paren, "(");
        btnValues.put(R.id.btn_close_paren, ")");
        btnValues.put(R.id.btn_sin, "sin(");
        btnValues.put(R.id.btn_cos, "cos(");
        btnValues.put(R.id.btn_tan, "tan(");
        btnValues.put(R.id.btn_sqrt, "sqrt(");

        for (Map.Entry<Integer, String> entry : btnValues.entrySet()) {
            View v = view.findViewById(entry.getKey());
            if (v != null) {
                v.setOnClickListener(vw -> {
                    currentExpression.append(entry.getValue());
                    tvDisplay.setText(currentExpression.toString());
                });
            }
        }

        view.findViewById(R.id.btn_clear).setOnClickListener(v -> {
            currentExpression.setLength(0);
            tvDisplay.setText("0");
        });

        view.findViewById(R.id.btn_backspace).setOnClickListener(v -> {
            if (currentExpression.length() > 0) {
                currentExpression.deleteCharAt(currentExpression.length() - 1);
                String text = currentExpression.toString();
                tvDisplay.setText(text.isEmpty() ? "0" : text);
            }
        });

        view.findViewById(R.id.btn_equals).setOnClickListener(v -> {
            String expr = currentExpression.toString();
            try {
                double result = ExpressionEvaluator.evaluate(expr);
                String resultText = String.valueOf(result);
                tvDisplay.setText(resultText);

                historyList.add(0, expr + " = " + resultText);
                historyAdapter.notifyDataSetChanged();

                currentExpression.setLength(0);
                currentExpression.append(resultText);
            } catch (Exception e) {
                tvDisplay.setText("Error");
                currentExpression.setLength(0);
            }
        });

        return view;
    }
}