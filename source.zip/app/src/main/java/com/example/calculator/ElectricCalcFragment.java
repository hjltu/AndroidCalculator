package com.example.calculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.fragment.app.Fragment;

public class ElectricCalcFragment extends Fragment {
    private EditText etU, etR, etI, etP;
    private TextView tvResult;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_electric_calc, container, false);

        etU = view.findViewById(R.id.et_u);
        etR = view.findViewById(R.id.et_r);
        etI = view.findViewById(R.id.et_i);
        etP = view.findViewById(R.id.et_p);
        tvResult = view.findViewById(R.id.tv_electric_result);

        view.findViewById(R.id.btn_electric_calc).setOnClickListener(v -> calculate());

        return view;
    }

    private Double parseField(EditText et) {
        String s = et.getText().toString().trim();
        if (s.isEmpty()) return null;
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void calculate() {
        Double u = parseField(etU);
        Double r = parseField(etR);
        Double i = parseField(etI);
        Double p = parseField(etP);

        int known = 0;
        if (u != null) known++;
        if (r != null) known++;
        if (i != null) known++;
        if (p != null) known++;

        if (known != 2) {
            tvResult.setText("Enter exactly 2 values");
            return;
        }

        StringBuilder sb = new StringBuilder();

        if (u != null && r != null) {
            // U and R known
            if (r == 0) { tvResult.setText("Error: R = 0"); return; }
            double calcI = u / r;
            double calcP = u * calcI;
            sb.append("I = ").append(fmt(calcI)).append(" A\n");
            sb.append("P = ").append(fmt(calcP)).append(" W");
        } else if (u != null && i != null) {
            // U and I known
            double calcR = u / i;
            double calcP = u * i;
            sb.append("R = ").append(fmt(calcR)).append(" Ω\n");
            sb.append("P = ").append(fmt(calcP)).append(" W");
        } else if (u != null && p != null) {
            // U and P known
            double calcI = p / u;
            double calcR = u / calcI;
            sb.append("I = ").append(fmt(calcI)).append(" A\n");
            sb.append("R = ").append(fmt(calcR)).append(" Ω");
        } else if (r != null && i != null) {
            // R and I known
            double calcU = r * i;
            double calcP = calcU * i;
            sb.append("U = ").append(fmt(calcU)).append(" V\n");
            sb.append("P = ").append(fmt(calcP)).append(" W");
        } else if (r != null && p != null) {
            // R and P known
            if (r == 0) { tvResult.setText("Error: R = 0"); return; }
            double calcU = Math.sqrt(p * r);
            double calcI = calcU / r;
            sb.append("U = ").append(fmt(calcU)).append(" V\n");
            sb.append("I = ").append(fmt(calcI)).append(" A");
        } else if (i != null && p != null) {
            // I and P known
            if (i == 0) { tvResult.setText("Error: I = 0"); return; }
            double calcU = p / i;
            double calcR = calcU / i;
            sb.append("U = ").append(fmt(calcU)).append(" V\n");
            sb.append("R = ").append(fmt(calcR)).append(" Ω");
        }

        tvResult.setText(sb.toString());
    }

    private String fmt(double value) {
        if (Math.abs(value) < 1e-12) return "0";
        if (value == (long) value) return String.valueOf((long) value);
        return String.valueOf(value);
    }
}