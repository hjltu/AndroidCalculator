package com.example.calculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.fragment.app.Fragment;

public class PidCalcFragment extends Fragment {
    private EditText etKu;
    private EditText etTu;
    private TextView tvKpResult;
    private TextView tvKiResult;
    private TextView tvKdResult;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pid_calc, container, false);

        etKu = view.findViewById(R.id.et_ku);
        etTu = view.findViewById(R.id.et_tu);
        tvKpResult = view.findViewById(R.id.tv_kp_result);
        tvKiResult = view.findViewById(R.id.tv_ki_result);
        tvKdResult = view.findViewById(R.id.tv_kd_result);

        view.findViewById(R.id.btn_pid_calc).setOnClickListener(v -> {
            String kuStr = etKu.getText().toString().trim();
            String tuStr = etTu.getText().toString().trim();

            if (kuStr.isEmpty() || tuStr.isEmpty()) {
                tvKpResult.setText("Kp = —");
                tvKiResult.setText("Ki = —");
                tvKdResult.setText("Kd = —");
                return;
            }

            try {
                double ku = Double.parseDouble(kuStr);
                double tu = Double.parseDouble(tuStr);

                if (tu == 0) {
                    tvKpResult.setText("Kp = Error");
                    tvKiResult.setText("Ki = Error (Tu=0)");
                    tvKdResult.setText("Kd = —");
                    return;
                }

                double kp = 0.6 * ku;
                double ki = 1.2 * ku / tu;
                double kd = 0.075 * ku * tu;

                tvKpResult.setText("Kp = " + formatResult(kp));
                tvKiResult.setText("Ki = " + formatResult(ki));
                tvKdResult.setText("Kd = " + formatResult(kd));
            } catch (NumberFormatException e) {
                tvKpResult.setText("Kp = Error");
                tvKiResult.setText("Ki = Error");
                tvKdResult.setText("Kd = Error");
            }
        });

        return view;
    }

    private String formatResult(double value) {
        if (Math.abs(value) < 1e-12) return "0";
        if (value == (long) value) return String.valueOf((long) value);
        return String.valueOf(value);
    }
}