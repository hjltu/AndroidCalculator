package com.example.calculator;

import java.util.*;

public class ExpressionEvaluator {
    public static double evaluate(String expression) {
        if (expression == null || expression.trim().isEmpty()) return 0;
        try {
            double result = new Parser(expression).parse();
            if (Math.abs(result) < 1e-12) {
                result = 0.0;
            }
            return result;
        } catch (Exception e) {
            throw new RuntimeException("Eval Error");
        }
    }

    private static class Parser {
        private final String str;
        private int pos = -1;
        private int ch;

        Parser(String str) {
            this.str = str;
        }

        void nextChar() {
            pos++;
            ch = (pos < str.length()) ? str.charAt(pos) : 0;
        }

        boolean eat(int charToEat) {
            while (pos < str.length() - 1 && ch == ' ') nextChar();
            if (ch == charToEat) {
                nextChar();
                return true;
            }
            return false;
        }

        double parse() {
            nextChar();
            double x = parseExpression();
            while (pos < str.length() && ch == ' ') nextChar();
            if (ch != 0) throw new RuntimeException("Unexpected: " + (char)ch);
            return x;
        }

        double parseExpression() {
            double x = parseTerm();
            for (;;) {
                if (eat('+')) x += parseTerm();
                else if (eat('-')) x -= parseTerm();
                else return x;
            }
        }

        double parseTerm() {
            double x = parseFactor();
            for (;;) {
                if (eat('*')) x *= parseFactor();
                else if (eat('/')) {
                    double div = parseFactor();
                    if (div == 0) throw new ArithmeticException("Div0");
                    x /= div;
                } else if (eat('^')) x = Math.pow(x, parseFactor());
                else if (eat('%')) x *= parseFactor() / 100.0;
                else return x;
            }
        }

        double parseFactor() {
            if (eat('(')) {
                double x = parseExpression();
                if (!eat(')')) throw new RuntimeException("Missing )");
                return x;
            }
            if (eat('-')) return -parseFactor();
            if (eat('+')) return parseFactor();

            if (ch >= 'a' && ch <= 'z') {
                StringBuilder sb = new StringBuilder();
                while (pos < str.length() && (ch >= 'a' && ch <= 'z')) {
                    sb.append((char)ch);
                    nextChar();
                }
                String func = sb.toString();
                if (!eat('(')) throw new RuntimeException("Expected ( after " + func);
                double x = parseExpression();
                if (!eat(')')) throw new RuntimeException("Missing ) after " + func);

                switch (func) {
                    case "sin": return Math.sin(Math.toRadians(x));
                    case "cos": return Math.cos(Math.toRadians(x));
                    case "tan": return Math.tan(Math.toRadians(x));
                    case "sqrt": return Math.sqrt(x);
                    default: throw new RuntimeException("Unknown function: " + func);
                }
            }

            int start = this.pos;
            if ((ch >= '0' && ch <= '9') || ch == '.') {
                while (pos < str.length() && ((ch >= '0' && ch <= '9') || ch == '.')) {
                    nextChar();
                }
                return Double.parseDouble(str.substring(start, pos));
            }
            throw new RuntimeException("Unexpected: " + (char)ch);
        }
    }
}
