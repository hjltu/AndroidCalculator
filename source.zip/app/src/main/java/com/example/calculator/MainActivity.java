package com.example.calculator;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    private MathCalcFragment mathFragment;
    private PidCalcFragment pidFragment;
    private ElectricCalcFragment electricFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mathFragment = new MathCalcFragment();
        pidFragment = new PidCalcFragment();
        electricFragment = new ElectricCalcFragment();

        TabLayout tabLayout = findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Math"));
        tabLayout.addTab(tabLayout.newTab().setText("PID"));
        tabLayout.addTab(tabLayout.newTab().setText("Electric"));

        // Load default tab
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, mathFragment)
                .commit();

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Fragment fragment;
                switch (tab.getPosition()) {
                    case 1:
                        fragment = pidFragment;
                        break;
                    case 2:
                        fragment = electricFragment;
                        break;
                    default:
                        fragment = mathFragment;
                        break;
                }
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, fragment)
                        .commit();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }
}